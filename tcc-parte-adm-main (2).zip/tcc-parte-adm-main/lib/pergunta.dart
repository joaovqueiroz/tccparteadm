import 'package:flutter/material.dart';

class AskPage extends StatelessWidget {
  AskPage({@required this.title, this.description, this.ramo});

  final title;
  final description;
  final ramo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
      centerTitle: true,
        title: Text(title),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[
              Color(0xFF00CED1),
                    Color(0xFF4682B4),
            ])          
         ),        
     ),      
 ),
        body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text('Descrição', style: TextStyle(fontWeight: FontWeight.bold),),
                Text(description),
                Text('Ramo', style: TextStyle(fontWeight: FontWeight.bold),),
                Text(ramo)
              ]),
        ));
  }
}